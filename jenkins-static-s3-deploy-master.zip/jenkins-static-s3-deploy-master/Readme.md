# Deploying a Static Website to AWS S3 using Jenkins or Github Actions  

For more details: https://amlanscloud.com/jenkinsdeploys3/